package com.zybooks.chelseapatel_inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView SignUp;
    private TextView Login;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SignUp = (TextView) findViewById(R.id.buttonSignUp);
        SignUp.setOnClickListener(this);

        Login = (TextView) findViewById(R.id.loginbtn);
        Login.setOnClickListener(this);
    }





    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonSignUp:
                startActivity(new Intent(this, SignUp.class));
                break;
            case R.id.loginbtn:

                startActivity(new Intent(this, Permission.class));
                break;


        }

    }
}
