package com.zybooks.chelseapatel_inventoryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class SignUp extends AppCompatActivity implements View.OnClickListener {
    private EditText InputUsername, InputPassword, InputWorkId, InputEmail;
    private TextView register;
    private FirebaseAuth mAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        mAuth = FirebaseAuth.getInstance();

       register = (Button) findViewById(R.id.btnRegister);
       register.setOnClickListener((View.OnClickListener) this);
       InputUsername = (EditText) findViewById(R.id.InputUsername);
       InputPassword = (EditText) findViewById(R.id.InputPassword);
       InputWorkId = (EditText) findViewById(R.id.InputWorkID);
       InputEmail = (EditText) findViewById(R.id.email);

    }
    @Override
    public void onClick(View v)
    {
        switch (v.getId()){
            case R.id.btnRegister:
                register();
                break;
        }

    }

    private void register() {
        String username = InputUsername.getText().toString().trim();
        String email = InputEmail.getText().toString().trim();
        String password = InputPassword.getText().toString().trim();
        String workId = InputWorkId.getText().toString().trim();

        if(username.isEmpty()){
            InputUsername.setError("Username is required");
            InputUsername.requestFocus();
            return;
        }
        if(email.isEmpty()){
            InputEmail.setError("Email is required");
            InputEmail.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            InputEmail.setError("Please provide valid email!");
            InputEmail.requestFocus();
            return;
        }
        if(password.isEmpty()){
            InputPassword.setError("Password is required");
            InputPassword.requestFocus();
            return;
        }
        if(password.length()<6){
            InputPassword.setError("Minimum password length should be 6 characters");
            InputPassword.requestFocus();
            return;
        }
        if(workId.isEmpty()){
            InputWorkId.setError("Work ID is required");
            InputWorkId.requestFocus();
            return;
        }

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            User user = new User(username, workId, email);

                            FirebaseDatabase.getInstance().getReference("Users")
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()){
                                                Toast.makeText(SignUp.this, "user has been registered successfully!", Toast.LENGTH_LONG).show();
                                            }
                                            else{
                                                Toast.makeText(SignUp.this, "Failed to register! Try again!", Toast.LENGTH_LONG).show();
                                            }

                                        }
                                    });

                        }else{
                            Toast.makeText(SignUp.this, "Failed to register!", Toast.LENGTH_LONG).show();
                        }
                    }
                });



    }


}