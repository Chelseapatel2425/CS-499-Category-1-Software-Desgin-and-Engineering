package com.zybooks.chelseapatel_inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class inventoryscreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventoryscreen);
    }
}