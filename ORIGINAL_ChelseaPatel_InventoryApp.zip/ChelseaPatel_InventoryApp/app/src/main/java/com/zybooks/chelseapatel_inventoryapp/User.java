package com.zybooks.chelseapatel_inventoryapp;

public class User {

    public String username, workId, email;
    public User(){

    }
    public User(String username, String workId, String email){
        this.username = username;
        this.workId = workId;
        this.email = email;
    }
}



