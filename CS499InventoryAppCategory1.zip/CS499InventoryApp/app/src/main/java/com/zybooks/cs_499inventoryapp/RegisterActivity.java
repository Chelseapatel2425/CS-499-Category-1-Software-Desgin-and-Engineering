package com.zybooks.cs_499inventoryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


public class RegisterActivity extends AppCompatActivity {

    TextView alreadyHaveaccount;
    EditText inputEmail, inputPassword, inputConfirmPassword;
    Button btnRegister;
    //Validation pattern for email
    //String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]";
    //create progress dialog
    ProgressDialog progressDialog;
    //create an instance of the firebase database
    FirebaseAuth mAuth;
    FirebaseUser mUser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        alreadyHaveaccount=findViewById(R.id.alreadyHaveaccount);

        //initialize all variables inputemail, inputpassword, inputconfirmpassword
        //initialize btnregister and also the progress dialog

        inputEmail=findViewById(R.id.inputEmail);
        inputPassword = findViewById(R.id.inputPassword);
        inputConfirmPassword = findViewById(R.id.inputConfirmPassword);
        btnRegister=findViewById(R.id.btnRegister);
        progressDialog = new ProgressDialog(this);
        //initialize mAuth for firebase database
        mAuth=FirebaseAuth.getInstance();
        mUser=mAuth.getCurrentUser();


        alreadyHaveaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RegisterActivity.this,MainActivity.class));

            }
        });

        //setting up on click listener for button register
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                performAuth();
                

            }
        });

    }

    private void performAuth() {
        //get tex from the input field
        String email=inputEmail.getText().toString();
        String password = inputPassword.getText().toString();
        String confirmPassword = inputConfirmPassword.getText().toString();

        //check to see if the user entered a valid email address
        /*if (!email.matches(emailPattern))
        {
            //toast method will display if the email does not match the email pattern
            //this will also be responsible to display an error message
            inputEmail.setError("Email is required. Please enter a valid email address");
            inputEmail.requestFocus();*/
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            inputEmail.setError("Please provide valid email!");
            inputEmail.requestFocus();
            return;

        }else if (password.isEmpty() || password.length()<6)
        {
            inputPassword.setError("Enter a password with minimum 6 characters");
            //inputPassword.requestFocus();

        }else if (!password.equals(confirmPassword))
        {
            inputConfirmPassword.setError("Password does not match. Please re-enter your password");
            //inputConfirmPassword.requestFocus();

        }
        else{
            progressDialog.setMessage("Please wait. Registration in progress");
            progressDialog.setTitle("Registeration");
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

            mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful())
                    {
                        progressDialog.dismiss();
                        //if the login is successful then the user is prompted to the next activity
                        sendUserToNextActivity();
                        Toast.makeText(RegisterActivity.this, "Registeration Successful", Toast.LENGTH_SHORT).show();
                    }else{
                        Log.d("TestExpe", "onComplete: "+task.getException().getLocalizedMessage().toString());
                        progressDialog.dismiss();
                        Toast.makeText(RegisterActivity.this, ""+task.getException(), Toast.LENGTH_SHORT).show();
                    }

                }
            });

        }


    }

    private void sendUserToNextActivity() {
        Intent intent = new Intent(RegisterActivity.this,InventoryActivity.class);

        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);

    }
}